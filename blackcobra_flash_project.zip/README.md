
# ⚠️ Black Cobra's Space

Ein privates Webprojekt für visuelle Effekte und Roblox-Prototyping.

## Features

- Schwarzer Fullscreen-Modus mit Flash-Warnung
- Videowiedergabe von TikTok-Inhalten
- Entwickelt für Testzwecke / Roblox Studio Referenz

## Lokale Verwendung

1. `index.html` öffnen
2. `warning.mp4` muss im selben Ordner liegen
3. Kein Hosting notwendig

> ⚠️ Nur für lokale Vorschau und Testzwecke gedacht
